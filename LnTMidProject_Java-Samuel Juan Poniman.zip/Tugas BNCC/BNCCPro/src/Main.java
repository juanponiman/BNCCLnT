import java.util.*;

public class Main {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> names = new ArrayList<String>();
	ArrayList<String> genders = new ArrayList<String>();
	ArrayList<String> categories = new ArrayList<String>();
	ArrayList<String> ids = new ArrayList<String>();
	ArrayList<Integer> wages = new ArrayList<Integer>();

	public void add() {
		String name, gender, id, category;
		Integer wage = null;
		while (true) {
			System.out.println("Input nama karyawan [>= 3]");
			name = scan.nextLine();
			if (name.length() >= 3 && name.length() <= 20 && name.split(" ").length >= 2) {
				break;
			}
			while (true) {
				System.out.println("Input jenis kelamin [Laki-laki | Perempuan]");
				gender = scan.nextLine();
				if (gender.contentEquals("Laki-laki") && gender.contentEquals("Perempuan")) {
					break;
				}
				while (true) {
					System.out.println("Input jabatan [Manager | Supervisor | Admin]:");
					category = scan.nextLine();
					if (category.contentEquals("Manager") && category.contentEquals("Supervisor")
							&& category.contentEquals("Admin")) {
						break;
					}
				}
				// random
				Random rand = new Random();
				id = "CU" + rand.nextInt(10) + rand.nextInt(10) + rand.nextInt(10 + rand.nextInt(10));
				char initial1 = name.charAt(0);
				char initial2 = name.charAt(0);
				id = Character.toString(initial1) + Character.toString(initial2) + rand.nextInt(10) + rand.nextInt(10);

				if (category.equals("Manager")) {
					wage = 8000000;
				} else if (category.equals("Supervisor")) {
					wage = 6000000;
				} else if (category.equals("Admin")) {
					wage = 4000000;
				}
				names.add(name);
				genders.add(gender);
				ids.add(id);
				wages.add(wage);
				categories.add(category);
			}
		}

	}

	public void view() {
		for (int i = 0; i < names.size(); i++) {
			for (int j = 0; j < names.size(); j++) {
				if (names.get(j).compareToIgnoreCase(names.get(j + 1)) > 0) {
					String nameTemp = names.get(j);
					names.set(j, names.get(j + 1));
					names.set(j + 1, nameTemp);

					String genderTemp = genders.get(j);
					genders.set(j, genders.get(j + 1));
					genders.set(j + 1, genderTemp);

					String idTemp = ids.get(j);
					ids.set(j, ids.get(j + 1));
					ids.set(j + 1, idTemp);

					Integer wageTemp = wages.get(j);
					wages.set(j, wages.get(j + 1));
					wages.set(j + 1, wageTemp);

					String categoryTemp = categories.get(j);
					categories.set(j, categories.get(j + 1));
					categories.set(j + 1, categoryTemp);

				}
				for (int i2 = 0; i2 < names.size(); i2++) {
					System.out.println("No: " + (i + 1));
					System.out.println("Kode Karyawan: " + ids.get(i2 + 1));
					System.out.println("Nama Karyawan:" + names.get(i2));
					System.out.println("Jenis Kelamin:" + genders.get(i2));
					System.out.println("Jabatan:" + categories.get(i2));
					System.out.println("Gaji Karyawan:" + wages.get(i2));
				}
			}
		}
	}

	public void remove() {
		view();
		Integer no;
		String id = null;
		System.out.println("Input nomor urutan karyawan yang ingin dihapus:");
		no = scan.nextInt();
		for (int i = 0; i < names.size(); i++) {
			names.remove(i);
			genders.remove(i);
			wages.remove(i);
			categories.remove(i);
		}
		System.out.println("Karyawan dengan kode" + id + "berhasil dihapus");
	}

	public void update() {
		view();
		String gender;
		String id = null;
		Integer no;
		String name, email, category;
		System.out.println("Input id to remove:");
		no = scan.nextInt();
		for (int i = 0; i < names.size(); i++) {
			if (ids.get(i).equals(id)) {
				System.out.println("Input nama karyawan [>=3]:");
				name = scan.nextLine();
				System.out.println("Input jenis kelamin [Laki-laki | Perempuan]:");
				gender = scan.nextLine();
				System.out.println("Input jabatan [Manager | Supervisor | Admin]:");
				category = scan.nextLine();

				Random rand = new Random();
				id = "CU" + rand.nextInt(10) + rand.nextInt(10) + rand.nextInt(10 + rand.nextInt(10));
				char initial1 = name.charAt(0);
				char initial2 = name.charAt(0);
				id = Character.toString(initial1) + Character.toString(initial2) + rand.nextInt(10) + rand.nextInt(10);

				System.out.println("Berhasil mengupdate karyawan dengan id" + id);
				System.out.println("ENTER to return");
				System.out.println();

				names.set(i, name);
				genders.set(i, gender);
				categories.set(i, category);
			}
		}
	}

	public Main() {
		int menu;
		while (true) {
			System.out.println("1. Add data");
			System.out.println("2. View data");
			System.out.println("3. Remove data");
			System.out.println("4. Update data");
			System.out.println("5. Exit");
			System.out.println(">>");
			menu = scan.nextInt();
			scan.nextLine();

			if (menu == 1) {
				add();
			} else if (menu == 2) {
				view();
			} else if (menu == 3) {
				remove();
			} else if (menu == 4) {
				update();
			} else if (menu == 5) {
				break;
			}
		}
	}

	public static void main(String[] args) {
		new Main();

	}

}
